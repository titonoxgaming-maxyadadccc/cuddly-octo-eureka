package dev.lelonio.square.ui.player

import androidx.compose.foundation.background
import dev.lelonio.square.ui.glass.backdrop.effects.blur
import dev.lelonio.square.ui.glass.backdrop.drawBackdrop
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.fadeOut
import androidx.compose.animation.fadeIn
import androidx.compose.animation.core.tween
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.adamglin.PhosphorIcons
import com.adamglin.phosphoricons.Fill
import com.adamglin.phosphoricons.Regular
import com.adamglin.phosphoricons.fill.Heart
import com.adamglin.phosphoricons.regular.Check
import dev.lelonio.square.ui.glass.backdrop.Backdrop
import dev.lelonio.square.R
import dev.lelonio.square.data.CatalogPlaylist
import dev.lelonio.square.ui.MainViewModel
import dev.lelonio.square.ui.components.Artwork

/**
 * Which playlist the playing track should go into.
 *
 * The plus in the player opens this. It stands where a heart used to, and the
 * heart is what it fixes: Liked Songs is one playlist out of the account's
 * several, and a button that could only ever add to that one spent its whole
 * width answering a question nobody asked.
 *
 * The rows do not close the sheet. Adding one track to two playlists is a
 * perfectly ordinary thing to want, and a sheet that dismissed itself on the
 * first tap would make it two round trips through the player.
 */
@Composable
fun AddToPlaylistSheet(
    state: MainViewModel.AddToPlaylistState,
    backdrop: Backdrop,
    onSelect: (CatalogPlaylist) -> Unit,
    onDismiss: () -> Unit,
) {
    // Upstream's GlassSheet, over the whole app; see GlassSheetHost.
    dev.lelonio.square.ui.components.GlassSheet(
        visible = state.open,
        onDismiss = onDismiss,
        scrollable = false,
    ) {
                dev.lelonio.square.ui.components.SheetTitle(stringResource(R.string.add_to_playlist))
                Text(
                    // Says what is being added: the sheet can outlive the track
                    // that opened it, since playback carries on underneath.
                    state.trackTitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = GlassInkDim,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 22.dp, end = 22.dp, top = 4.dp, bottom = 14.dp),
                )

                if (state.error != null) {
                    Text(
                        state.error,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp),
                    )
                }

                if (state.done != null || state.removed != null) {
                    Text(
                        if (state.removed != null) {
                            stringResource(R.string.removed_from, state.removed.orEmpty())
                        } else {
                            stringResource(R.string.added_to, state.done.orEmpty())
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp),
                    )
                }

                if (state.playlists.isEmpty()) {
                    Text(
                        stringResource(R.string.no_playlists_in_account),
                        style = MaterialTheme.typography.bodyMedium,
                        color = GlassInkDim,
                        modifier = Modifier.padding(horizontal = 22.dp, vertical = 12.dp),
                    )
                } else {
                    Column(
                        Modifier
                            .heightIn(max = 360.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                    ) {
                        state.playlists.ticksFirst(state).forEach { playlist ->
                            PlaylistRow(
                                playlist = playlist,
                                busy = state.busy == playlist.uri,
                                added = state.done == playlist.name,
                                // Liked Songs is the one row that knows where
                                // the track already is, and the one a second
                                // press takes it out of.
                                liked = state.liked && playlist.uri.endsWith(":collection"),
                                inIt = playlist.uri in state.containing,
                                enabled = state.trackUri != null && state.busy == null,
                                onClick = { onSelect(playlist) },
                            )
                        }
                    }
                }
    }
}

/**
 * The picker itself, without a sheet around it.
 *
 * The player puts this in the panel that shows the lyrics and the queue instead
 * of opening a modal over the transport; everywhere else still gets the sheet.
 */
@Composable
fun PlaylistPicker(
    state: MainViewModel.AddToPlaylistState,
    onSelect: (CatalogPlaylist) -> Unit,
) {
            Column(Modifier.padding(vertical = 18.dp)) {
                Text(
                    stringResource(R.string.add_to_playlist),
                    style = MaterialTheme.typography.titleLarge,
                    color = GlassInk,
                    modifier = Modifier.padding(start = 22.dp, end = 22.dp),
                )
                Text(
                    // Says what is being added: the sheet can outlive the track
                    // that opened it, since playback carries on underneath.
                    state.trackTitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = GlassInkDim,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(start = 22.dp, end = 22.dp, top = 2.dp, bottom = 12.dp),
                )

                if (state.error != null) {
                    Text(
                        state.error,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp),
                    )
                }

                if (state.done != null || state.removed != null) {
                    Text(
                        if (state.removed != null) {
                            stringResource(R.string.removed_from, state.removed.orEmpty())
                        } else {
                            stringResource(R.string.added_to, state.done.orEmpty())
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp),
                    )
                }

                if (state.playlists.isEmpty()) {
                    Text(
                        stringResource(R.string.no_playlists_in_account),
                        style = MaterialTheme.typography.bodyMedium,
                        color = GlassInkDim,
                        modifier = Modifier.padding(horizontal = 22.dp, vertical = 12.dp),
                    )
                } else {
                    Column(
                        Modifier
                            .heightIn(max = 360.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                    ) {
                        state.playlists.ticksFirst(state).forEach { playlist ->
                            PlaylistRow(
                                playlist = playlist,
                                busy = state.busy == playlist.uri,
                                added = state.done == playlist.name,
                                // Liked Songs is the one row that knows where
                                // the track already is, and the one a second
                                // press takes it out of.
                                liked = state.liked && playlist.uri.endsWith(":collection"),
                                inIt = playlist.uri in state.containing,
                                enabled = state.trackUri != null && state.busy == null,
                                onClick = { onSelect(playlist) },
                            )
                        }
                    }
                }
            }
}

@Composable
private fun PlaylistRow(
    playlist: CatalogPlaylist,
    busy: Boolean,
    added: Boolean,
    /** In Liked Songs already, so this row removes rather than adds. */
    liked: Boolean = false,
    /** In this playlist already, so this row removes rather than adds. */
    inIt: Boolean = false,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Artwork(
            url = playlist.artworkUrl,
            title = playlist.name,
            modifier = Modifier.size(44.dp),
            corner = 10.dp,
            decodeSize = 44.dp,
        )
        Text(
            playlist.name,
            style = MaterialTheme.typography.titleMedium,
            color = GlassInk,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .padding(start = 16.dp)
                .weight(1f),
        )
        when {
            busy -> CircularProgressIndicator(
                color = GlassInkDim,
                strokeWidth = 2.dp,
                modifier = Modifier.size(18.dp),
            )

            liked -> Icon(
                PhosphorIcons.Fill.Heart,
                contentDescription = stringResource(R.string.remove_from_liked),
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp),
            )

            inIt -> Icon(
                PhosphorIcons.Regular.Check,
                contentDescription = stringResource(R.string.remove_from_playlist),
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp),
            )

            added -> Icon(
                PhosphorIcons.Regular.Check,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp),
            )
        }
    }
}

/**
 * The lists the track is already in, at the top: they are the ones this panel
 * is opened to find when the song is ticked, and further down a long list of
 * playlists they were a scroll away. Otherwise in the order they came, which
 * is the library's.
 */
private fun List<CatalogPlaylist>.ticksFirst(state: MainViewModel.AddToPlaylistState) =
    sortedByDescending { playlist ->
        playlist.uri in state.containing || (state.liked && playlist.uri.endsWith(":collection"))
    }
