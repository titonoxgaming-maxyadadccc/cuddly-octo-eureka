package dev.lelonio.square.ui.player

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.sin

/**
 * Small "dandiya" bars that rise and fall in the cover's own colour while the
 * song plays: tall on the beat, short between.
 *
 * This is an animation keyed to a steady tempo, not an analysis of the audio:
 * the decoded samples never reach the UI layer. Each bar has its own phase and
 * speed so the row reads as music rather than as a metronome. Paused, the bars
 * settle to a low line.
 */
@Composable
fun BeatBars(
    color: Color,
    playing: Boolean,
    modifier: Modifier = Modifier,
    height: Dp = 44.dp,
    bars: Int = 36,
    bpm: Float = 118f,
) {
    val transition = rememberInfiniteTransition(label = "beatBars")
    // One full beat, in turns: 0..1 repeating.
    val beat by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween((60_000f / bpm).toInt(), easing = LinearEasing), RepeatMode.Restart),
        label = "beat",
    )
    // A slower drift so neighbouring bars do not move in lock-step.
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 6.2831855f,
        animationSpec = infiniteRepeatable(tween(5200, easing = LinearEasing), RepeatMode.Restart),
        label = "drift",
    )
    val phases = remember(bars) { FloatArray(bars) { i -> ((i * 37) % 17) / 17f * 6.2831855f } }

    Canvas(modifier.fillMaxWidth().height(height)) {
        val slot = size.width / bars
        val barWidth = slot * 0.52f
        val corner = CornerRadius(barWidth / 2f, barWidth / 2f)
        // A punch at the start of each beat that dies away quickly.
        val punch = (1f - beat).let { it * it * it }
        for (i in 0 until bars) {
            val centre = 1f - abs((i - bars / 2f) / (bars / 2f)) * 0.55f
            val wobble = 0.5f + 0.5f * sin(drift * (1f + (i % 5) * 0.35f) + phases[i])
            val level = if (playing) {
                (0.14f + (0.35f * wobble + 0.5f * punch * wobble) * centre).coerceIn(0.08f, 1f)
            } else {
                0.08f
            }
            val h = size.height * level
            val x = i * slot + (slot - barWidth) / 2f
            drawRoundRect(
                brush = Brush.verticalGradient(
                    0f to color.copy(alpha = 0.95f),
                    1f to color.copy(alpha = 0.25f),
                    startY = size.height - h,
                    endY = size.height,
                ),
                topLeft = Offset(x, size.height - h),
                size = Size(barWidth, h),
                cornerRadius = corner,
            )
        }
    }
}
